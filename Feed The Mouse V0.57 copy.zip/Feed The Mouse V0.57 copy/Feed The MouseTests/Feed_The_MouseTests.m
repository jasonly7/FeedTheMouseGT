//
//  Feed_The_MouseTests.m
//  Feed The MouseTests
//
//  Created by Jason Ly on 2012-11-18.
//  Copyright (c) 2012 Jason Ly. All rights reserved.
//

#import "Feed_The_MouseTests.h"

@implementation Feed_The_MouseTests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in Feed The MouseTests");
}

@end
