//
//  World.m
//  Feed The Mouse
//
//  Created by Jason Ly on 2014-03-26.
//  Copyright (c) 2014 Jason Ly. All rights reserved.
//

#import "World.h"

@implementation World

- (id) init
{
    self = [super init];
    if (self)
    {
        
    }
    return self;
}
- (void)checkCollision :( CollisionPacket **) colPackage
{
    cheese->colPackage->foundCollision = false;
    for (int i = 0; i < [lvl->gears count]; i++ )
    {
        Gear *gear = [lvl->gears objectAtIndex:i];
        if ([cheese collideWithCircle:gear])
        {
            [mouse openMouth];
            [cheese bounceOffGear:gear];
        }
    }
    for (int i = 0; i < [lvl->drums count]; i++)
    {
        Drum *drum = [lvl->drums objectAtIndex:i];
        cheese->colPackage->foundCollision = [cheese checkDrum:drum];
        if (cheese->colPackage->foundCollision)
        {
            cheese->initVel = cheese->bounceVel;
            [cheese bounceOffDrum];
            break;
        }
        
    }
    if (cheese->colPackage->foundCollision==false)
    {
        for (int i = 0; i < [lvl->teeterTotters count]; i++ )
        {
            TeeterTotter *teeterTotter = [lvl->teeterTotters objectAtIndex:i];
            cheese->colPackage->foundCollision = [cheese checkTeeterTotter:teeterTotter];
            if (cheese->colPackage->foundCollision)
            {
                if (cheese->pos->x > teeterTotter->x)
                    teeterTotter->angle-=1;
                else if (cheese->pos->x < teeterTotter->x)
                    teeterTotter->angle+=1;
                break;
            }
        }
    }
    if ([cheese collideWithMouse])
    {
        CGPoint pt = CGPointMake(cheese->x,-960);
        [cheese dropAt:pt];
        [mouse chew];
    }
}

- (void)setMouse :(Mouse **)m
{
    mouse = *m;
}

- (void)setCheese:(Cheese **)c
{
    cheese = *c;
}

- (void)setLevel :(Level *)level
{
    lvl = level;
}
@end
