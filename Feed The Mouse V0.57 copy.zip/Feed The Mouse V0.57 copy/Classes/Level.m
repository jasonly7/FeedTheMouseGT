//
//  Level.m
//  Feed The Mouse Level Editor
//
//  Created by Jason Ly on 2013-03-24.
//  Copyright (c) 2013 Jason Ly. All rights reserved.
//

#import "Level.h"

@implementation Level
- (void) initializeLevel:(int) number
{
    num = number;
    gears = [[NSMutableArray alloc] initWithCapacity:10];
    drums = [[NSMutableArray alloc] initWithCapacity:10];
    teeterTotters = [[NSMutableArray alloc] initWithCapacity:10];
}

-(void) addGear:(Gear*) g
{
    [gears addObject:g];
}

-(void) addDrum:(Drum*) d
{
    [drums addObject:d];
}

-(void) addTeeterTotter:(TeeterTotter *)t
{
    [teeterTotters addObject:t];
}

-(NSMutableArray*) getGears
{
    return gears;
}

-(NSMutableArray*) getDrums
{
    return drums;
}

-(NSMutableArray*) getTeeterTotters
{
    return teeterTotters;
}

@end
