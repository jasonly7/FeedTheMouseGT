//
//  TitleScreenViewController.h
//  Feed The Mouse
//
//  Created by Jason Ly on 2013-03-23.
//  Copyright (c) 2013 Jason Ly. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TitleScreenViewController : UIViewController

@property (retain,nonatomic) UIButton *button;

-(IBAction)buttonpressed:(id)sender;
@end
