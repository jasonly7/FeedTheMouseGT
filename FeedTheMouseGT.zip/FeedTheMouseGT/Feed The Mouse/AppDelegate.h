//
//  AppDelegate.h
//  Feed The Mouse
//
//  Created by Jason Ly on 2012-11-18.
//  Copyright (c) 2012 Jason Ly. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TitleScreenViewController;

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) TitleScreenViewController *viewController;

@end
