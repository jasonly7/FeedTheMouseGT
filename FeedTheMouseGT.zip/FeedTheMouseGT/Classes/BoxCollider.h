//
//  BoxCollider.h
//  Feed The Mouse
//
//  Created by Jason Ly on 2014-03-14.
//  Copyright (c) 2014 Jason Ly. All rights reserved.
//

#import "Collider.h"

@interface BoxCollider : Collider

@end
