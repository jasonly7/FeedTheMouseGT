//
//  Collider.h
//  Feed The Mouse
//
//  Created by Jason Ly on 2014-03-14.
//  Copyright (c) 2014 Jason Ly. All rights reserved.
//

#import <Foundation/Foundation.h>


typedef enum {
    NONE = 0,
    BOUNCE,
    SLIDE
} RESPONSE;

@interface Collider : NSObject
{
    
}
@end
