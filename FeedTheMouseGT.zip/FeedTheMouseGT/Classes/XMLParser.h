//
//  XMLParser.h
//  Feed The Mouse
//
//  Created by Jason Ly on 2013-02-02.
//  Copyright (c) 2013 Jason Ly. All rights reserved.
//

#import <Foundation/Foundation.h>
@class Gear;
@class Level;
@class Drum;
@class TeeterTotter;

@interface XMLParser : NSObject
{
    NSMutableString *currentElementValue;
    NSString *currentElementName;
    NSString *currentObject;
    Gear *gear;
    Drum *drum;
    TeeterTotter *teeterTotter;
    Level *level;
    int x, y;
    float angle;
    int lvlNum;
@public
    NSMutableArray *gears;
    NSMutableArray *drums;
    NSMutableArray *teeterTotters;
    NSMutableArray *levels;
}

@property (nonatomic, retain) Gear *gear;
@property (nonatomic, retain) Drum *drum;
@property (nonatomic, retain) TeeterTotter *t;
@property (nonatomic, retain) Level *level;
@property (nonatomic, retain) NSMutableArray *gears;
@property (nonatomic, retain) NSMutableArray *levels;

- (XMLParser *) initXMLParser;
@end
