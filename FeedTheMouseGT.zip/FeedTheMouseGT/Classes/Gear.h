//
//  Gear.h
//  Feed The Mouse
//
//  Created by Jason Ly on 2012-12-24.
//  Copyright (c) 2012 Jason Ly. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Picture.h"
#import "Circle.h"

const int GEAR_HEIGHT = 174;
const int GEAR_WIDTH = 174;

@interface Gear : Circle
{
    @public
        Sprite *gearSprite;
        float rotateAngle;
}
- (void) initializeGearWithX :(int)gx andY:(int) gy;
- (void) draw: (CGContextRef) context;
- (void) rotate;
- (void) setX: (int) x;
- (void) setY: (int) y;
- (int) getX;
- (int) getY;
@end
