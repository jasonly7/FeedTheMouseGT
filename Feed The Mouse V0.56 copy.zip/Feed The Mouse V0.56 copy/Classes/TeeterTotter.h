//
//  TeeterTotter.h
//  Feed The Mouse Level Editor
//
//  Created by Jason Ly on 2014-03-06.
//  Copyright (c) 2014 Jason Ly. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Picture.h"
const int TEETER_TOTTER_HEIGHT = 72;
const int TEETER_TOTTER_WIDTH = 180;

typedef enum {
    TEETER_TOTTER_WAIT = 0,
    TEETER_TOTTER_RESET,
    TEETER_TOTTER_ROTATING
} TEETER_TOTTER_STATE;

@interface TeeterTotter : NSObject
{
    @public
    int x,y;
    Sprite *totterSprite;
    float angle;
    TEETER_TOTTER_STATE state;
}

- (TeeterTotter*) initializeTeeterTotterAtX:(float) tx andY: (float)ty;
- (void) draw: (CGContextRef) context;
- (int)getX;
- (int)getY;
- (void) setX: (int) value;
- (void) setY: (int) value;
- (float)getAngle;
- (void) setAngle: (float) value;
- (void) rotateClockwise: (float) value;
- (void) rotateCounterClockwise: (float) value;
- (void) update;
@end
