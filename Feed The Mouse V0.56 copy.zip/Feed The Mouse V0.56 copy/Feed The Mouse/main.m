//
//  main.m
//  Feed The Mouse
//
//  Created by Jason Ly on 2012-11-18.
//  Copyright (c) 2012 Jason Ly. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
