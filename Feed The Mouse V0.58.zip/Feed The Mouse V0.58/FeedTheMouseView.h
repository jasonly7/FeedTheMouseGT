//
//  FeedTheMouseView.h
//  FeedTheMouse
//
//  Created by Jason Ly on 2012-10-28.
//  Copyright (c) 2012 Jason Ly. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Sprite.h"
#import "AtlasSprite.h"
#import "Picture.h"
#import "Cheese.h"
#import "Mouse.h"
#import "Gear.h"
#import "Drum.h"
#import "VectorSprite.h"
#import "XMLParser.h"
#import "Level.h" 

@interface FeedTheMouseView : UIView {
    Sprite *mouseSprite;
    Sprite *backgroundSprite;

    Cheese *cheese;
    Mouse *mouse;
    Gear *gear;
    Drum *drum;
    TeeterTotter *teeterTotter;
    
    NSTimer *timer;

	int direction;
    int t;
    int animationNumber;
    CGContextRef context;
    XMLParser *parser;
    NSMutableArray *gears;
    NSMutableArray *drums;
    NSMutableArray *teeterTotters;
    NSMutableArray *levels;
    int currentLevelNumber;
    Level *curLevel;

    NSDate * levelStartDate;
    NSDate *lastDate;
    double next_game_tick;
    double cur_game_tick;
    double delta_tick;
    bool game_is_running;
    int loops;
    float interpolation;
}

- (void) doParse:(NSData *) data;
- (void) gameLoop;
- (void) update_game;
- (void) display_game:(double) lerp;
@end
