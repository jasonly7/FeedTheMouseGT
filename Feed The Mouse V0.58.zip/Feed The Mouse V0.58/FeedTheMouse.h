//
//  FeedTheMouse.h
//  FeedTheMouse
//
//  Created by Jason Ly on 2012-10-13.
//  Copyright (c) 2012 Jason Ly. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FeedTheMouse : UIView

@end
