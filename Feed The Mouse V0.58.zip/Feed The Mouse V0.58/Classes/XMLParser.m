//
//  XMLParser.m
//  Feed The Mouse
//
//  Created by Jason Ly on 2013-02-02.
//  Copyright (c) 2013 Jason Ly. All rights reserved.
//

#import "XMLParser.h"
#import "Gear.h"
#import "Level.h"
@implementation XMLParser

@synthesize gear;
@synthesize level;
- (XMLParser *) initXMLParser {
    [super init];
    levels = [[NSMutableArray alloc] initWithCapacity:3];
    gears = [[NSMutableArray alloc] initWithCapacity:3];
    drums = [[NSMutableArray alloc] initWithCapacity:3];
    teeterTotters = [[NSMutableArray alloc] initWithCapacity:3];
    lvlNum = 0;
    return self;
}

- (void)parser:(NSXMLParser *)parser didStartElement:(NSString *)elementName
  namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qualifiedName
    attributes:(NSDictionary *)attributeDict
{
    currentElementName = elementName;

    if ([elementName isEqualToString:@"Gear"]) {
        NSLog(@"gear element found – create a new instance of Gear class...");
        gear = [[Gear alloc] init];
        currentObject = @"Gear";
        //We do not have any attributes in the gear elements, but if
        // you do, you can extract them here:
        // gear = [[attributeDict objectForKey:@"<att name>"] ...];
    }
    else if ([elementName isEqualToString:@"Drum"]) {
        drum = [[Drum alloc] init];
        currentObject = @"Drum";
    }
    else if ([elementName isEqualToString:@"TeeterTotter"])
    {
        teeterTotter = [[TeeterTotter alloc] init];
        currentObject = @"TeeterTotter";
    }
    else if ([elementName isEqualToString:@"Level"]) {
        lvlNum++;
        level = [[Level alloc] init];
        [level initializeLevel:lvlNum];
        currentObject = @"";
    }
    
}

- (void) parser: (NSXMLParser *)parser foundCharacters:(NSString *)string {
    if (!currentElementValue) {
        // init the ad hoc string with the value
        currentElementValue = [[NSMutableString alloc] initWithString:string];
    } else {
        // append value to the ad hoc string
        [currentElementValue appendString:string];
    }
   // printf("string: %s", [string UTF8String]);
    if ([currentElementName isEqualToString:@"X"])
    {
        if ([currentObject isEqualToString:@"Gear"])
            x = [string intValue]-GEAR_WIDTH;
        else if ([currentObject isEqualToString:@"Drum"])
            x = [string intValue];
        else if ([currentObject isEqualToString:@"TeeterTotter"])
            x = [string intValue]-TEETER_TOTTER_WIDTH;
        currentElementName = @"";
    } else if ([currentElementName isEqualToString:@"Y"]) {
        if ([currentObject isEqualToString:@"Gear"])
            y = [string intValue]-GEAR_HEIGHT;
        else if ([currentObject isEqualToString:@"Drum"])
            y = [string intValue];
        else if ([currentObject isEqualToString:@"TeeterTotter"])
            y = [string intValue]-TEETER_TOTTER_HEIGHT;
        currentElementName = @"";
    } else if ([currentElementName isEqualToString:@"ANGLE"]) {
        angle = [string floatValue];
        currentElementName = @"";
    }

    NSLog(@"Processing value for : %s", [string UTF8String]);
}

- (void)parser:(NSXMLParser *)parser didEndElement:(NSString *)elementName namespaceURI:(NSString *)namespaceURI qualifiedName:(NSString *)qName
{
    if ([elementName isEqualToString:@"FeedTheMouse"]) {
        // We reached the end of the XML document
        return;
    }
    
    if ([elementName isEqualToString:@"Level"])
    {

        for (int i=0; i < gears.count; i++)
        {
            Gear *newGear = [[[Gear alloc] init] autorelease];
            Gear *g = (Gear*)[gears objectAtIndex:i];
            int gx = [g getX];
            int gy = [g getY];
            [newGear initializeGearWithX:gx andY:gy];
            [level addGear:newGear];
        }
        for (int i=0; i < drums.count; i++)
        {
            Drum *newDrum = [[[Drum alloc] init] autorelease];
            Drum *d = (Drum*)[drums objectAtIndex:i];
            int dx = [d getX];
            int dy = [d getY];
            float newAngle = [d getAngle];
            [newDrum initializeDrumAtX:dx andY:dy andAngle:newAngle];
            [level addDrum:newDrum];
        }
        for (int i=0; i < teeterTotters.count; i++)
        {
            TeeterTotter *newTeeterTotter = [[[TeeterTotter alloc] init] autorelease];
            TeeterTotter *t = (TeeterTotter*)[teeterTotters objectAtIndex:i];
            int tx = [t getX];
            int ty = [t getY];
            [newTeeterTotter initializeTeeterTotterAtX:tx andY:ty];
            [level addTeeterTotter:newTeeterTotter];
        }
        [levels addObject:level];
        [gears removeAllObjects];
        [drums removeAllObjects];
        [teeterTotters removeAllObjects];
    }
         
    if ([elementName isEqualToString:@"Gear"]) {
        // We are done with user entry – add the parsed user
        // object to our user array
        [gear setX:x];
        [gear setY:y];
        [gears addObject:gear];
        //printf("Gear(x,y): %d %d\n", [gear getX], [gear getY]);
        // release user object
       // [gear release];
        //gear = nil;
    }
    if ([elementName isEqualToString:@"Drum"]) {
        [drum setX:x];
        [drum setY:y];
        [drum setAngle:angle];
        [drums addObject:drum];
    }
    if ([elementName isEqualToString:@"TeeterTotter"]) {
        [teeterTotter setX:x];
        [teeterTotter setY:y];
        
        [teeterTotters addObject:teeterTotter];
    }
    [currentElementValue release];
    currentElementValue = nil;
}
@end
