//
//  FeedTheMouseDocument.h
//  Feed The Mouse
//
//  Created by Jason Ly on 2013-01-31.
//  Copyright (c) 2013 Jason Ly. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface FeedTheMouseDocument : NSDocument

@end
