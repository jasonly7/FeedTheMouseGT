//
//  Cheese.h
//  Feed The Mouse
//
//  Created by Jason Ly on 2012-12-02.
//  Copyright (c) 2012 Jason Ly. All rights reserved.
//

#import "Picture.h"
#import "Circle.h"
#import "Mouse.h"
#import "Vector.h"
#import "Gear.h"
#import "TeeterTotter.h"
#import "Physics.h"
#import "Force.h"
#import "Vector.h"
#import "Matrix.h"
#import "Quadratic.h"
#import "CollisionPacket.h"
#import "World.h"
@class World;

@interface Cheese : Circle
{
    
    float accel;
    
    float timeOfCollision;

    
    Force *gravityForce;
    Force *normalForce;
    Force *bounceForce;
    bool isBouncing;
    NSNumber *x1;
    Vector *collisionPoint;
   // bool flag;

 //   Vector *newPosition;
    Vector *eSpaceintersectionPt;
    float eSpaceNearestDist;
    int collisionRecursionDepth;
    @public
        Vector *initVel;
        Vector *bounceVel;
        Line *slidingLine;
        Sprite *cheeseSprite;
        NSMutableArray *gears;
        NSMutableArray *drums;
        NSMutableArray *teeterTotters;
      //  Gear *gear;
       // Drum *drum;
        //TeeterTotter *teeterTotter;
        Mouse *mouse;
        CollisionPacket *colPackage;
        Vector *vel; // velocity in R2
        float t;
        float time;
        float timeUntilImpact;
        World *world;
        Vector *gravity;
}
- (void) draw: (CGContextRef) context;
- (void) dropAt: (CGPoint) pt;
- (void) fall: (float) interpolation;
- (void) display: (double) lerp;
- (bool) collideWithMouse;
//- (void) onCollide: (NSObject *) obj;
- (void) bounceOffGear: (Gear*) gear;
- (void) bounceOffDrum;
- (void) bounceOffTeeterTotter;
- (void) slideOffTeeterTotter:(TeeterTotter *)totter;
- (bool) checkDrum: (Drum*) d;
- (bool) checkTeeterTotter: (TeeterTotter*) totter;
- (bool) collideWithLine: (Line *)line;
- (bool) collideWithVertex: (CGPoint) pt;
- (void) collideAndSlide;
- (Vector*) collideWithWorldPosition: (const Vector*)position andVelocity: (const Vector*) velocity;
- (void) moveTo: (Vector*) position;
@end
